package br.edu.fatecpg.projdbc.view;

import br.edu.fatecpg.projdbc.db.DB;
import br.edu.fatecpg.projdbc.model.*;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        try(var conn = DB.connection()) {
            System.out.println("Conexão Realizada com Sucesso");
            var query = "INSERT INTO tb_alunos(cpf,nome) VALUES(?,?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1,"412.222.333-44");
            stmt.setString(2,"Alessandro Lima");
            stmt.execute();
            List<Aluno> Alunos = new ArrayList<>();
            var consulta = "SELECT * FROM tb_alunos";
            PreparedStatement stmConsulta = conn.prepareStatement(consulta);
            ResultSet rs = stmConsulta.executeQuery();
            while (rs.next()) {
                Alunos.add(new Aluno(
                    rs.getInt("id"),
                    rs.getString("cpf"),
                    rs.getString("nome")));
            }
            Alunos.forEach(System.out::println);
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }
}
